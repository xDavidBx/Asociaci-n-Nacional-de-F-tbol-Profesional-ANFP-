-- Generado por Oracle SQL Developer Data Modeler 24.3.1.347.1153
--   en:        2026-10-11 21:15:11 CLST
--   sitio:      Oracle Database 21c
--   tipo:      Oracle Database 21c



-- predefined type, no DDL - MDSYS.SDO_GEOMETRY

-- predefined type, no DDL - XMLTYPE

CREATE SEQUENCE seq_club_futbol START WITH 703 INCREMENT BY 4 NOCACHE;

CREATE TABLE asociacion (
    id_asociacion     NUMBER(3) NOT NULL,
    nombre_asociacion VARCHAR2(80) NOT NULL,
    fecha_creacion    DATE NOT NULL,
    tipo_asociacion   CHAR(1) NOT NULL
)
LOGGING;

ALTER TABLE asociacion
    ADD CONSTRAINT ck_asociacion_fecha CHECK ( fecha_creacion >= DATE '1980-12-31' );

ALTER TABLE asociacion
    ADD CONSTRAINT ck_asociacion_tipo CHECK ( tipo_asociacion IN ( 'P', 'A' ) );

ALTER TABLE asociacion ADD CONSTRAINT pk_asociacion PRIMARY KEY ( id_asociacion );

CREATE TABLE club_futbol (
    id_club         NUMBER(5) NOT NULL,
    nombre_club     VARCHAR2(60) NOT NULL,
    patrimonio      NUMBER(15) DEFAULT 0 NOT NULL,
    ubicacion_calle VARCHAR2(100) NOT NULL,
    tipo_club       VARCHAR2(12) DEFAULT 'Profesional' NOT NULL
)
LOGGING;

ALTER TABLE club_futbol ADD CONSTRAINT ck_club_futbol_pat CHECK ( patrimonio >= 0 );

ALTER TABLE club_futbol
    ADD CONSTRAINT ck_club_futbol_tipo CHECK ( tipo_club IN ( 'Profesional', 'Amateur' ) );

ALTER TABLE club_futbol ADD CONSTRAINT pk_club_futbol PRIMARY KEY ( id_club );

ALTER TABLE club_futbol ADD CONSTRAINT un_club_futbol_nom UNIQUE ( nombre_club );

CREATE TABLE comuna (
    id_comuna NUMBER(4) NOT NULL,
    id_region NUMBER(2) NOT NULL,
    nombre    VARCHAR2(60) NOT NULL
)
LOGGING;

ALTER TABLE comuna ADD CONSTRAINT pk_comuna PRIMARY KEY ( id_comuna );

CREATE TABLE escuela_futbol (
    id_escuela      NUMBER(5) NOT NULL,
    nombre_escuela  VARCHAR2(80) NOT NULL,
    capacidad       NUMBER(6) NOT NULL,
    fecha_fundacion DATE NOT NULL
)
LOGGING;

ALTER TABLE escuela_futbol ADD CONSTRAINT ck_escuela_futbol_cap CHECK ( capacidad > 0 );

ALTER TABLE escuela_futbol ADD CONSTRAINT pk_escuela_futbol PRIMARY KEY ( id_escuela );

CREATE TABLE idioma (
    id_idioma     NUMBER(3) NOT NULL,
    nombre_idioma VARCHAR2(40) NOT NULL
)
LOGGING;

ALTER TABLE idioma ADD CONSTRAINT pk_idioma PRIMARY KEY ( id_idioma );

ALTER TABLE idioma ADD CONSTRAINT un_idioma_nom UNIQUE ( nombre_idioma );

CREATE TABLE jugador (
    num_inscripcion     NUMBER(9) NOT NULL,
    puesto              VARCHAR2(20) NOT NULL,
    monto_total_premios NUMBER(12) DEFAULT 0 NOT NULL,
    id_asociacion       NUMBER(3) NOT NULL,
    id_escuela          NUMBER(5),
    anio_fin_amateur    NUMBER(4)
)
LOGGING;

ALTER TABLE jugador
    ADD CONSTRAINT ck_jugador_escuela_anio
        CHECK ( ( id_escuela IS NULL
                  AND anio_fin_amateur IS NULL )
                OR ( id_escuela IS NOT NULL
                     AND anio_fin_amateur IS NOT NULL ) );

ALTER TABLE jugador ADD CONSTRAINT ck_jugador_premios CHECK ( monto_total_premios >= 0 );

ALTER TABLE jugador
    ADD CONSTRAINT ck_jugador_puesto
        CHECK ( puesto IN ( 'Arquero', 'Defensa', 'Mediocampista', 'Delantero' ) );

ALTER TABLE jugador ADD CONSTRAINT pk_jugador PRIMARY KEY ( num_inscripcion );

CREATE TABLE jugador_club (
    num_inscripcion     NUMBER(9) NOT NULL,
    id_club             NUMBER(5) NOT NULL,
    fecha_incorporacion DATE NOT NULL,
    fecha_fin_contrato  DATE
)
LOGGING;

CREATE UNIQUE INDEX ux_jugador_club_vigente ON
    jugador_club (
        CASE
            WHEN
                fecha_fin_contrato
            IS NULL THEN
                    num_inscripcion
        END
    );

ALTER TABLE jugador_club
    ADD CONSTRAINT ck_jugador_club_fechas
        CHECK ( fecha_fin_contrato IS NULL
                OR fecha_fin_contrato >= fecha_incorporacion );

ALTER TABLE jugador_club
    ADD CONSTRAINT pk_jugador_club PRIMARY KEY ( num_inscripcion,
                                                 id_club,
                                                 fecha_incorporacion );

CREATE TABLE jugador_idioma (
    num_inscripcion NUMBER(9) NOT NULL,
    id_idioma       NUMBER(3) NOT NULL,
    nivel_dominio   VARCHAR2(12) DEFAULT 'Basico' NOT NULL
)
LOGGING;

ALTER TABLE jugador_idioma
    ADD CONSTRAINT ck_jugador_idioma_nivel
        CHECK ( nivel_dominio IN ( 'Basico', 'Intermedio', 'Avanzado', 'Nativo' ) );

ALTER TABLE jugador_idioma ADD CONSTRAINT pk_jugador_idioma PRIMARY KEY ( num_inscripcion,
                                                                          id_idioma );

CREATE TABLE nacionalidad (
    id_nacion   NUMBER(4)
        GENERATED ALWAYS AS IDENTITY ( START WITH 210 INCREMENT BY 2 NOCACHE )
    NOT NULL,
    descripcion VARCHAR2(40) NOT NULL
)
LOGGING;

ALTER TABLE nacionalidad ADD CONSTRAINT pk_nacionalidad PRIMARY KEY ( id_nacion );

ALTER TABLE nacionalidad ADD CONSTRAINT un_nacionalidad_descrip UNIQUE ( descripcion );

CREATE TABLE personal_planta (
    num_inscripcion  NUMBER(9) NOT NULL,
    id_club          NUMBER(5) NOT NULL,
    horas_trabajadas NUMBER(4),
    valor_hora_extra NUMBER(8)
)
LOGGING;

ALTER TABLE personal_planta ADD CONSTRAINT ck_personal_planta_horas CHECK ( horas_trabajadas >= 0 );

ALTER TABLE personal_planta ADD CONSTRAINT ck_personal_planta_valor CHECK ( valor_hora_extra >= 0 );

ALTER TABLE personal_planta ADD CONSTRAINT pk_personal_planta PRIMARY KEY ( num_inscripcion );

CREATE TABLE region (
    id_region NUMBER(2) NOT NULL,
    nombre    VARCHAR2(60) NOT NULL
)
LOGGING;

ALTER TABLE region ADD CONSTRAINT pk_region PRIMARY KEY ( id_region );

CREATE TABLE trabajador (
    num_inscripcion  NUMBER(9) NOT NULL,
    rut              NUMBER(8) NOT NULL,
    dv_rut           CHAR(1) NOT NULL,
    nombres          VARCHAR2(60) NOT NULL,
    apellido_paterno VARCHAR2(40) NOT NULL,
    apellido_materno VARCHAR2(40),
    sueldo_base      NUMBER(10) DEFAULT 0 NOT NULL,
    fecha_nacimiento DATE NOT NULL,
    genero           CHAR(1) NOT NULL,
    estado_civil     VARCHAR2(15) NOT NULL,
    telefono_movil   VARCHAR2(15) NOT NULL,
    direccion        VARCHAR2(120) NOT NULL,
    id_comuna        NUMBER(4) NOT NULL,
    id_nacion        NUMBER(4) NOT NULL
)
LOGGING;

ALTER TABLE trabajador
    ADD CONSTRAINT ck_trabajador_dv
        CHECK ( dv_rut IN ( '0', '1', '2', '3', '4',
                            '5', '6', '7', '8', '9',
                            'K' ) );

ALTER TABLE trabajador
    ADD CONSTRAINT ck_trabajador_ecivil
        CHECK ( estado_civil IN ( 'Soltero', 'Casado', 'Divorciado', 'Viudo', 'Conviviente' ) );

ALTER TABLE trabajador
    ADD CONSTRAINT ck_trabajador_genero CHECK ( genero IN ( 'M', 'F' ) );

ALTER TABLE trabajador ADD CONSTRAINT ck_trabajador_sueldo CHECK ( sueldo_base >= 0 );

ALTER TABLE trabajador ADD CONSTRAINT pk_trabajador PRIMARY KEY ( num_inscripcion );

ALTER TABLE trabajador ADD CONSTRAINT un_trabajador_rut UNIQUE ( rut );

ALTER TABLE comuna
    ADD CONSTRAINT fk_comuna_region
        FOREIGN KEY ( id_region )
            REFERENCES region ( id_region )
            NOT DEFERRABLE;

ALTER TABLE jugador
    ADD CONSTRAINT fk_jugador_asociacion
        FOREIGN KEY ( id_asociacion )
            REFERENCES asociacion ( id_asociacion )
            NOT DEFERRABLE;

ALTER TABLE jugador_club
    ADD CONSTRAINT fk_jugador_club_club
        FOREIGN KEY ( id_club )
            REFERENCES club_futbol ( id_club )
            NOT DEFERRABLE;

ALTER TABLE jugador_club
    ADD CONSTRAINT fk_jugador_club_jugador
        FOREIGN KEY ( num_inscripcion )
            REFERENCES jugador ( num_inscripcion )
            NOT DEFERRABLE;

ALTER TABLE jugador
    ADD CONSTRAINT fk_jugador_escuela
        FOREIGN KEY ( id_escuela )
            REFERENCES escuela_futbol ( id_escuela )
            NOT DEFERRABLE;

ALTER TABLE jugador_idioma
    ADD CONSTRAINT fk_jugador_idioma_idioma
        FOREIGN KEY ( id_idioma )
            REFERENCES idioma ( id_idioma )
            NOT DEFERRABLE;

ALTER TABLE jugador_idioma
    ADD CONSTRAINT fk_jugador_idioma_jug
        FOREIGN KEY ( num_inscripcion )
            REFERENCES jugador ( num_inscripcion )
            NOT DEFERRABLE;

ALTER TABLE jugador
    ADD CONSTRAINT fk_jugador_trabajador
        FOREIGN KEY ( num_inscripcion )
            REFERENCES trabajador ( num_inscripcion )
            NOT DEFERRABLE;

ALTER TABLE personal_planta
    ADD CONSTRAINT fk_personal_planta_club
        FOREIGN KEY ( id_club )
            REFERENCES club_futbol ( id_club )
            NOT DEFERRABLE;

ALTER TABLE personal_planta
    ADD CONSTRAINT fk_personal_planta_trab
        FOREIGN KEY ( num_inscripcion )
            REFERENCES trabajador ( num_inscripcion )
            NOT DEFERRABLE;

ALTER TABLE trabajador
    ADD CONSTRAINT fk_trabajador_comuna
        FOREIGN KEY ( id_comuna )
            REFERENCES comuna ( id_comuna )
            NOT DEFERRABLE;

ALTER TABLE trabajador
    ADD CONSTRAINT fk_trabajador_nacion
        FOREIGN KEY ( id_nacion )
            REFERENCES nacionalidad ( id_nacion )
            NOT DEFERRABLE;



-- Informe de Resumen de Oracle SQL Developer Data Modeler: 
-- 
-- CREATE TABLE                            12
-- CREATE INDEX                             1
-- ALTER TABLE                             44
-- CREATE VIEW                              0
-- ALTER VIEW                               0
-- CREATE PACKAGE                           0
-- CREATE PACKAGE BODY                      0
-- CREATE PROCEDURE                         0
-- CREATE FUNCTION                          0
-- CREATE TRIGGER                           0
-- ALTER TRIGGER                            0
-- CREATE COLLECTION TYPE                   0
-- CREATE STRUCTURED TYPE                   0
-- CREATE STRUCTURED TYPE BODY              0
-- CREATE CLUSTER                           0
-- CREATE CONTEXT                           0
-- CREATE DATABASE                          0
-- CREATE DIMENSION                         0
-- CREATE DIRECTORY                         0
-- CREATE DISK GROUP                        0
-- CREATE ROLE                              0
-- CREATE ROLLBACK SEGMENT                  0
-- CREATE SEQUENCE                          1
-- CREATE MATERIALIZED VIEW                 0
-- CREATE MATERIALIZED VIEW LOG             0
-- CREATE SYNONYM                           0
-- CREATE TABLESPACE                        0
-- CREATE USER                              0
-- 
-- DROP TABLESPACE                          0
-- DROP DATABASE                            0
-- 
-- REDACTION POLICY                         0
-- 
-- ORDS DROP SCHEMA                         0
-- ORDS ENABLE SCHEMA                       0
-- ORDS ENABLE OBJECT                       0
-- 
-- ERRORS                                   0
-- WARNINGS                                 0
